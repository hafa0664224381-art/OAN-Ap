OAN Android project — source files prepared for Android Studio

Included:
- Native Android WebView shell (Kotlin)
- OAN branding and Arabic/French interface
- Individual photo cards with category filters and full-screen image viewer
- Paint color guide and psychological associations
- Placo-plâtre, gypsum, ceilings, decoration sections
- WhatsApp request form and contact link for +213 664 224 381
- Local HTML and logo bundled in app assets

Important:
- This is an Android Studio source project, NOT a compiled APK.
- Gallery photos load from Unsplash URLs and therefore need an internet connection; use only photos you have permission to publish and replace them with your own project photos when available.
- To build APK: open this folder in Android Studio, allow Gradle sync, then choose Build > Build Bundle(s) / APK(s) > Build APK(s). Android Studio will show the resulting APK path. For distribution, generate a signed APK and keep the signing key safe.
- Website URL was not provided, so this prototype currently opens its bundled app rather than embedding the existing website. Once the URL is known, the app can be configured to open it or combine it with this gallery.
